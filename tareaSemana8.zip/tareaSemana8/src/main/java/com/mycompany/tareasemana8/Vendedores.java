package com.mycompany.tareasemana8;

import java.util.Scanner;

/**
 *
 * @author wpena
 */
public class Vendedores
{
    Scanner entrada;
    
    public Vendedores()
    {
        entrada = new Scanner(System.in);
    }

    public void ejecutar()
            
    {   int vendedores[] = new int [6];
        int eleccion =0,election = 0;
        while(true){
            System.out.println("Elija uno de los 5 vendedores");
            
               eleccion = entrada.nextInt();
               
             vendedores[eleccion] = eleccion;
            if( vendedores[eleccion] != 0)
            {
                while(true)
                {
                    System.out.println("Digite el valor de la venta del vendedor: ");
                    election = entrada.nextInt();
                    vendedores[eleccion] += election;
           
                   if ( election == 0)
                   {
                       break;
                   }
                }
            }
            if (eleccion == 0)
            {
                break;
            }
            
        }
        imprimirVendedor(vendedores);
    }
    void imprimirVendedor(int[] vendedores)
    {
    int posicion = 1;
        while(posicion < vendedores.length)
        {
            System.out.println("El vendedor: " + (posicion + 1) +" vendio un monto total de: " + vendedores[posicion]);
            posicion ++;
        }      
    }
}
