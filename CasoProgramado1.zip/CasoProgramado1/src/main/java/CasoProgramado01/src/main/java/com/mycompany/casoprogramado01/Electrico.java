/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CasoProgramado01.src.main.java.com.mycompany.casoprogramado01;

/**
 *
 * @author wpena
 */
public abstract class Electrico extends Pokemon
{
    private String Pikachu;
    private float Vida = 500;
    private int Thunder = 55;
    private int VoltTakle  = 40;

    public Electrico(String Pikachu, float Vida, int Thunder, int VoltTakle)
    {
        this.Pikachu = Pikachu;
        this.Vida = Vida;
        this.Thunder = Thunder;
        this.VoltTakle = VoltTakle;
    }

    public String getPikachu() {
        return Pikachu;
    }

    public void setPikachu(String Pikachu) {
        this.Pikachu = Pikachu;
    }

    public float getVida() {
        return Vida;
    }

    public void setVida(float Vida) {
        this.Vida = Vida;
    }

    public int getThunder() {
        return Thunder;
    }

    public void setThunder(int Thunder) {
        this.Thunder = Thunder;
    }

    public int getVoltTakle() {
        return VoltTakle;
    }

    public void setVoltTakle(int VoltTakle) {
        this.VoltTakle = VoltTakle;
    }
    
}
