/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CasoProgramado01.src.main.java.com.mycompany.casoprogramado01;

/**
 *
 * @author wpena
 */
public abstract class Fuego extends Pokemon
{
    private String Chramander;
    private float Vida = 500;
    private int TailOnFire = 52;
    private int Flare = 43;

    public Fuego(String Charmander, float vida, int TailOnFire, int Flare)
    {
        this.Chramander = Charmander;
        this.Vida = vida;
        this.TailOnFire = TailOnFire;
        this.Flare = Flare;
        
    }

    public String getChramander() {
        return Chramander;
    }

    public void setChramander(String Chramander) {
        this.Chramander = Chramander;
    }

    public float getVida() {
        return Vida;
    }

    public void setVida(float Vida) {
        this.Vida = Vida;
    }

    public int getTailOnFire() {
        return TailOnFire;
    }

    public void setTailOnFire(int TailOnFire) {
        this.TailOnFire = TailOnFire;
    }

    public int getFlare() {
        return Flare;
    }

    public void setFlare(int Flare) {
        this.Flare = Flare;
    }
    
}
