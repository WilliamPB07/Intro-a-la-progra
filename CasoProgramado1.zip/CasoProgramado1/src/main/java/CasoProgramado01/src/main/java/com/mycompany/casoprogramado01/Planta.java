/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CasoProgramado01.src.main.java.com.mycompany.casoprogramado01;

/**
 *
 * @author wpena
 */
public abstract class Planta extends Pokemon
{
    private String Bublbasur;
    private float Vida = 500;
    private int VineWhip = 49;
    private int RazorLeaf = 49;

    public Planta(String Bublbasur, float Vida, int VineWhip, int RazorLeaf ) 
    {
        this.Bublbasur = Bublbasur;
        this.Vida = Vida;
        this.VineWhip = VineWhip;
        this.RazorLeaf = RazorLeaf;
    }

    public String getBublbasur() {
        return Bublbasur;
    }

    public void setBublbasur(String Bublbasur) {
        this.Bublbasur = Bublbasur;
    }

    public float getVida() {
        return Vida;
    }

    public void setVida(float Vida) {
        this.Vida = Vida;
    }

    public int getVineWhip() {
        return VineWhip;
    }

    public void setVineWhip(int VineWhip) {
        this.VineWhip = VineWhip;
    }

    public int getRazorLeaf() {
        return RazorLeaf;
    }

    public void setRazorLeaf(int RazorLeaf) {
        this.RazorLeaf = RazorLeaf;
    }
    
    
}
