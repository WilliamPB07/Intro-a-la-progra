/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package CasoProgramado01.src.main.java.com.mycompany.casoprogramado01;

/**
 *
 * @author wpena
 */
public abstract class Agua extends Pokemon
{
    private String Squirtle;
    private float Vida = 500;
    private int Bubble = 48;
    private int WaterGun = 65;
    

    public Agua(float vida, int Ataque, int Defensa)
    {
        this.Squirtle = Squirtle;
        this.Vida = Vida;
        this.Bubble = Bubble;
        this.WaterGun = WaterGun;
    }

    public String getSquirtle() {
        return Squirtle;
    }

    public void setSquirtle(String Squirtle) {
        this.Squirtle = Squirtle;
    }

    public float getVida() {
        return Vida;
    }

    public void setVida(float vida) {
        this.Vida = vida;
    }

    public int getAtaque() {
        return Bubble;
    }

    public void setAtaque(int Ataque) {
        this.Bubble = Ataque;
    }

    public int getDefensa() {
        return WaterGun;
    }

    public void setDefensa(int Defensa) {
        this.WaterGun = WaterGun;
    }
   
}
