/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vectores;

import java.util.Scanner;

/**
 *
 * @author wpena
 */
public class Ejemplo01 
{
    Scanner entrada = new Scanner(System.in);
    
    
    public void ejecutar()
    {
        int edades[] = new int[10];
        for(int indice = 0; indice < edades.length; indice++)
        {
            System.out.println("Escriba la edad de la persona en posicion " + (indice + 1));
            edades[indice] = entrada.nextInt();
        }
        int posicion = 0;
        while(posicion < edades.length)
        {
            System.out.println
                    ("La persona en la posicion: " + (posicion + 1) +" tiene "+ edades[posicion] + " años.");
            posicion ++;
        }
    }
}