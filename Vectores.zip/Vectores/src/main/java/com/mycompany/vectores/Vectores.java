/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.vectores;

import java.util.Scanner;

/**
 *
 * @author wpena
 */
public class Vectores {

    public static void main(String[] args) 
    {
        Scanner reader = new Scanner(System.in);
        int elejir = reader.nextInt();
        
        if (elejir == 1)
        {
            Ejemplo01 programa = new Ejemplo01();
            programa.ejecutar();
        }
        else if(elejir == 2)
        {
            Ejercicio01 programa = new Ejercicio01();
            programa.ejecutar();
        }
       
    }
}