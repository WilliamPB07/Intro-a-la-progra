/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.vectores;

import java.util.Scanner;

/**
 *
 * @author wpena
 */
public class Ejercicio01
{
    Scanner entrada;

    public Ejercicio01()
    {
       entrada = new Scanner(System.in);
    }
    
    
    public void ejecutar()
    {
        System.out.println("Digite el tamaño para el arreglo de edades: ");
        int tamano = entrada.nextInt();
        
        int edades[] = crearArreglo(tamano);
      
        imprimirArreglo(edades);
        
        System.out.println("Digite la edad que desea buscar en el arreglo. ");
        int edad = entrada.nextInt();
        int posicion = buscarEdad(edades, edad);
        
        if (posicion == -1)
        {
            System.out.println("La edad " + edad + " no se encuentra dentro del arreglo. ");
        }
        else{
            System.out.println("La edad " + edad + " se encuentra en la posicion: " + posicion + "."); 
       }
    }
    
    int[] crearArreglo(int tamano)
    {
        int edades[] = new int[tamano];
        
        for(int indice = 0; indice < edades.length; indice++)
        {
            System.out.println("Escriba la edad de la persona en posicion " + (indice + 1));
            edades[indice] = entrada.nextInt();
        }
        return edades;
    }
    
    void imprimirArreglo(int[] edades)
    {
        int posicion = 0;
        while(posicion < edades.length)
        {
            System.out.println
                    ("La persona en la posicion: " + (posicion + 1) +" tiene "+ edades[posicion] + " años.");
            posicion ++;
        }
    }
    
    int buscarEdad(int[] edades, int edad)
    {
        for(int i = 0; i < edades.length; i++)
        {
            if(edades[i] == edad)
            {
                return i;
            }
        }
        return -1;
    }
}